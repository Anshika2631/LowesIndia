package com.example.calculator;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@Data
@Entity
public class Input {
  
  private UUID id;
  private int firstNum;
  private int secondNum;
  private String operation;
  private int result;
  
  //parameterized cotructor
  
  
  
}
