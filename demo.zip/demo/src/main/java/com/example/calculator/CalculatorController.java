package com.example.calculator;

import java.util.List;

@RestController
public class CalculatorController {   
	@Autowired
	private CalculatorService calculatorService;
	
	@RequestMapping(method="ResponseMethod.POST",value="/add/{firstNum}/{secondNum}")
	public int addNumbers(@PathVariable int firstNum,@PathVariable int secondNum) {
		return calculatorService.performOperation(firstNum,secondNum,"add");	
	}
	
	@RequestMapping(method="ResponseMethod.POST",value="/sub/{firstNum}/{secondNum}")
	public int subNumbers(@PathVariable int firstNum,@PathVariable int secondNum) {
		return calculatorService.performOperation(firstNum,secondNum,"sub");	
	}
	
	@RequestMapping(method="ResponseMethod.POST",value="/mul/{firstNum}/{secondNum}")
	public int mulNumbers(@PathVariable int firstNum,@PathVariable int secondNum) {
		return calculatorService.performOperation(firstNum,secondNum,"mul");	
	}
	@RequestMapping(method="ResponseMethod.POST",value="/div/{firstNum}/{secondNum}")
	public int divNumbers(@PathVariable int firstNum,@PathVariable int secondNum) {
		return calculatorService.performOperation(firstNum,secondNum,"div");	
	}
	@RequestMapping(method="ResponseMethod.GET",value="/getAllData")
	public List<Input> getAllData() {
		return calculatorService.getAllDataFromDb();	
	}
}
