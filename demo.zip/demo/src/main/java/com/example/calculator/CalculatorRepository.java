package com.example.calculator;

public interface CalculatorRepository extends CrudRepository<Input,UUID> {
  
}
