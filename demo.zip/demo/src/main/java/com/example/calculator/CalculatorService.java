package com.example.calculator;

import java.util.List;
import java.util.UUID;

@Service
public class CalculatorService {
	
@Autowired
private CalculatorRepository calculatorRepository;

	//add the numbers
	public int performOperation(int firstNum,int secondNum,String operation) {
		int result;
		if(operation.equalsIgnoreCase("add"))
		 result = firstNum + secondNum;
		else if(operation.equalsIgnoreCase("sub"))
		result=firstNum-secondNum;
		else if(operation.equalsIgnoreCase("mul"))
		result=firstNum * secondNum;
		else if(operation.equalsIgnoreCase("div")) {
			result=firstNum/secondNum;
		}	
		Input ip=new Input(UUID.randomUUID(),firstNum,secondNum,operation,result);		
		calculatorRepository.save(ip);
		return result;
	}
	
	public List<Input> getAllDataFromDb(){
		List<Input> results=new ArrayList<>();
		results=calculatorRepository.findAll();		
		return results;
	}
	
}
